#include<stdlib.h>
#include<unistd.h>

int main(){
    
    char* firstCommand[] = {"ls", "-l" , NULL};
    char* secondCommand[] = {"pwd", NULL};

    __pid_t id;

    id = fork();

    if(id == -1)
        printf("error, process failed");

    if(id == 0)
        execvp("ls", firstCommand);

    else
        execvp("pwd", secondCommand);

return 0;

}

