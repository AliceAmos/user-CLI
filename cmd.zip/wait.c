#include<stdlib.h>
#include<unistd.h>

int main(){

    __pid_t first, second;

    first = fork();

    if(first == -1 || second == -1)
        printf("error, process failed");

    if(first == 0){
        printf("this is son 1, my pid is %d\n" , getpid());
        exit(0);
    }

    else{
        
        second = fork();
        
        if(second == -1)
            printf("error, process failed");

        if(second == 0){
            printf("this is son 2, my pid is %d\n", getpid());
            exit(0);
        }
        
        wait(NULL);

        printf("i am parent, my pid is %d\n", getpid());
    }

    return 0;
}
