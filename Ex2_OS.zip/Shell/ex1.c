#include <pwd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

void prompt(){                                              // method to print on the screen the prompt of the shell "username@directory>"

    char *direct = (char *)malloc(50 * sizeof(char));       // allocate memory to get the directory path

    if (direct == NULL)
    {
        perror("allocation didn't succeed");
        exit(1);
    }

    getcwd(direct, 50);                                     // get the directory path into the allocated memory

    if (direct == NULL)
    {
        perror("can't find directory");
        exit(1);
    }

    uid_t user = geteuid();                                 // get the user ID
    struct passwd *pswrd = getpwuid(user);                  // get the password of this user accourding to the ID

    if (pswrd == NULL)
    {
        perror("can't find username");
        exit(1);
    }

    printf("\n%s@%s>", pswrd->pw_name, direct);         // print username and directory path according to the required display

    free(direct);                                       // free the allocated memory
}

int main(int argc, char* argv[]){

    int lfds = open(argv[1], O_WRONLY | O_CREAT | O_APPEND, S_IRWXU);

    char *input = (char *)malloc(510 * sizeof(char));   // allocate memory for the user's input

    if (input == NULL)
        perror("allocation didn't succeed");

    double commands = 0,pcommands = 0, drcommands = 0, cmdlen = 0, cmdavg = 0;        // set varaiables to count the amount of commands, length of each command and calculate the average

    while (strcmp("done\0", input) != 0){               // when the user types "done" exit the shell and the print as required

        prompt();                                       // call the function above to show the prompt of the shell
        fgets(input, 510, stdin);                       // get the user's input

        input[strlen(input) - 1] = '\0';                // since the command ends with \n, replace it with \0 to cut the last character

        write(lfds, input, strlen(input));
        write(lfds, "\n", sizeof(char));

        if (strcmp("cd", input) == 0){                  // in case the command "cd" is entered
                
            printf("command not supported (Yet)");
            commands++;                                 // rais the commands' counter
            cmdlen += 2;                                // add the length of this command, which is 2 charcters
            continue;                                   // this command is not supported, move to the next iteration
        }

        char* orgIn = (char*)malloc((strlen(input)+1)*sizeof(char));            // save the original input before taking actions on it  
        int pipcount = 0, pipidx = 0, drc = 0;                                  
        int drcount = 0, odrcount = 0, ddrcount = 0, dr2count = 0, dridx = 0;
        int j;

        for (j = 0; j < strlen(input); j++){

            orgIn[j] = input[j];                                                // copy the input

            if (input[j] == '|'){                                               // in case there is a pipe sign, change it with ' ', save the index
                
                pipidx = j;
                pipcount++;
                input[j] = ' ';
            }


            if (input[j] == '>' && input[j+1] != '>'){                           // in case there is a > sign, change it with ' ', save the index
            
                drcount++;
                dridx = j;
                drc++;
                input[j] = ' ';
            }

            if (input[j] == '<'){                                               // in case there is a < sign, change it with ' ', save the index
            
                odrcount++;
                dridx = j;
                drc++;
                input[j] = ' ';
            }

            if (input[j] == '>' && input[j + 1] == '>'){                        // in case there is a >> sign, change it with ' ', save the index
            
                ddrcount++;
                dridx = j;
                drc++;
                input[j] = ' ';
                input[j+1] = ' ';
            }

            if (input[j] == '2' && input[j + 1] == '>'){                        // in case there is a 2> sign, change it with ' ', save the index
            
                dr2count++;
                dridx = j;
                drc++;
                input[j] = ' ';
                input[j+1] = ' ';
            }
        }

        orgIn[j] ='\0';                              // end of the input
        cmdlen += strlen(orgIn);                     // add the length of the command to the relevant counter

        int i, cmdcount = 0;
        for (i = 0; i < strlen(orgIn); i++){        // count the spaces that seperate between the command and its arguments

            if (input[i] == ' ')
                cmdcount++;
        }

        char **toExec = (char **)malloc((cmdcount + 2) * sizeof(char *)); // allocate memory to save each command/argument as a seperated string (array of char)

        if (toExec == NULL)
            perror("allocation didn't succeed");

        i = 0;
        char *cutpart = strtok(input, " ");     // save the first word entered in the user's input (cut from the begining to the first occurence of space)

        while (cutpart != NULL){                // untill there are no more arguments to seperate

            toExec[i] = (char *)malloc((strlen(cutpart) + 1) * sizeof(char)); // allocate memory for the cutted part(command/argument) of the input

            if (toExec[i] == NULL)
                perror("allocation didn't succeed");

            strcpy(toExec[i], cutpart);         // copy the data to the allocated memory
            cutpart = strtok(NULL, " ");        // skip to the next word seperated by space
            i++;
        }
        
        toExec[i] = NULL;                       // end of commands and arguments  
        cmdcount = i+1;                         // update the amount of commands and arguments  

        if (pipcount == 0 && drc == 0){         // in case of commands without pipe and redirection

            pid_t id;

            id = fork();                                                        // create a process

            if (id == -1)                                                       // in case there was a failure creating the process
                perror("error, process failed");

            if (id == 0){                                                       // son process
                execvp(toExec[0], toExec);                                      // execute the command that was entered by the user, the first cell holds the command, the next cells holds the arguments
                exit(0);
            }

            else{                                                               // "father"
                wait(NULL);                                                     // don't proceed untill the son process finishes

                free(cutpart);                                                  // free all allocated memory

                for (i = 0; i < cmdcount; i++)
                    free(toExec[i]); 

                free(toExec);
            }

            commands++;                                                         // raise the counter of commands
        }

        else if (pipcount > 0){                                                     // commands include pipe

            int sideActr = 0;
            char* tempIN = (char*)malloc((pipidx)*sizeof(char));                    // save the part of the input til the pipe  

            for(i=0; i<pipidx; i++){                                                // copy the data  
                tempIN[i] = orgIn[i];
           }

            char *tmpcut = strtok(tempIN, " ");                                     // cut the first command till the ' '

            while(tmpcut != NULL){                                                  // keep cutting commands seperated by ' '

                tmpcut = strtok(NULL," ");
                sideActr++;                                                         // count commands till the pipe
            }


            char **sideA = (char **)malloc((sideActr + 1) * sizeof(char*));         // allocate arrays, sideA till the pipe and sideB from the pipe to the end 
            char **sideB = (char **)malloc((cmdcount - sideActr + 1) * sizeof(char*));

            int a = 0, b = 0;

            while (a < sideActr){                                                   // hold the commands till the pipe 

                sideA[a] = toExec[a];
                a++;
            }
                                                                            

            while (a < cmdcount+2 && b < (cmdcount - sideActr +1) && toExec[a] != NULL){    // hold the commands after the pipe

                sideB[b] = toExec[a];
                b++;
                a++;
            }


            int pipe_[2];
            if (pipe(pipe_) == -1){                                                         // create a pipe

                perror("cannot create pipe");
                exit(1);
            }

            pid_t sonA, sonB;

            sonA = fork();                                                                  // create the first son process

            if(sonA == 0){                                                                  // in case this is the first son

                close(pipe_[0]);                                                            // close reading from the pipe
                if(dup2(pipe_[1],1) == -1)                                                  // write output to the writing side of the pipe
                    perror("couldn't change file descriptor");
                    
                else{                                                                     
                    execvp(sideA[0], sideA);                                                // execute the commands this array holds
                    exit(0);
                }
            }

            sonB = fork();                                                                  // create the second son process

            if(drc > 0){                                                                    // in case the command include pipe and redirection

                int curridx = 0;

                while(sideB[curridx] != NULL)                                               // find the last cell of the sideB array, holds the name of the file wishing to redirct to
                    curridx++;      
                    

                char* pfile = (char*)malloc(((strlen(sideB[curridx-1]))+1)*sizeof(char));   // allocate memory for the name of the file
                strcpy(pfile, sideB[curridx-1]);                                            // copy the data
                sideB[curridx-1] = NULL;                                                    // delete the last cell, which is not one of the arguments of the second command
       
                if(sonB == 0){                                                              // in case this is the second son

                    close(pipe_[1]);                                                        // close writing to the pipe

                    if(drcount > 0){                                                        // in case the redirection is a > sign

                        int pfds = open(pfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRWXU);      // change fd to the given file, with the right permissions
                        if(dup2(pipe_[0],0) == -1)
                            perror(" couldn't change file descriptor");
                        if(dup2(pfds, STDOUT_FILENO) == -1)                                 // change output according to the fd
                            perror("couldn't change file descriptor");
                        

                        else{
                            execvp(sideB[0], sideB);                                        // execute the command after the pipe 
                            exit(0);
                        }
                    }
   
                    if(ddrcount > 0){                                                       // in case the redirection is a >> sign

                        int pfds = open(pfile, O_WRONLY | O_CREAT | O_APPEND, S_IRWXU);     // change fd to the given file, with the right permissions, now append
                        if(dup2(pipe_[0],0) == -1)
                            perror(" couldn't change file descriptor");
                        if(dup2(pfds, STDOUT_FILENO) == -1)                                 // change output according to the fd
                            perror("couldn't change file descriptor");
                        

                        else{
                            execvp(sideB[0], sideB);                                        // execute the command after the pipe
                            exit(0);
                        }
                    }

                    if(dr2count > 0){                                                       // in case the redirection is a 2> sign

                        int pfds = open(pfile, O_WRONLY | O_CREAT | O_TRUNC, S_IRWXU);      // change fd to the given file, with the right permissions
                        if(dup2(pipe_[0],0) == -1)                                         
                            perror(" couldn't change file descriptor");
                        if(dup2(pfds, STDERR_FILENO) == -1)                                 // change error output according to the fd
                            perror("couldn't change file descriptor");
                        

                        else{
                            execvp(sideB[0], sideB);                                        // execute the command after the pipe
                            exit(0);
                        }
                    }
                }
                drcommands++;                                                              
            }

            else{                                                                       // no redirection, just a pipe
                if(sonB == 0){

                    close(pipe_[1]);                                                    // close writing to the pipe
                    if(dup2(pipe_[0],0) == -1)                                          
                        perror(" couldn't change file descriptor");
                    
                    else{
                        execvp(sideB[0], sideB);                                        // execute the command after the pipe
                        exit(0);
                    }
                }

            }

            if(getpid() != 0){                                                      // in case this is the father process

                close(pipe_[0]);                                                    // close both sides of the pipe
                close(pipe_[1]);
                wait(NULL);                                                         // wait for both son processes to end
                wait(NULL);
            }

            commands++;
            pcommands++;
        }

        else if(drc > 0 && pipcount == 0){                                         // in case the input has only redirection, no pipe
                
            int ctr = 0;
            char* tmpIN = (char*)malloc((dridx)*sizeof(char));                     // allocate memory for the command till the redirection
            char* file = (char*)malloc((strlen(orgIn)-dridx +2)*sizeof(char));     // the rest of the input from the redirection to the end is the name of the file we redirect to 

            for(i=0; i<dridx; i++){
                    
                tmpIN[i] = orgIn[i];                                                // copy the data till the redirection sign fron the original input
            }

            int i=0;
            char **seperated = (char **)malloc((ctr + 2)*sizeof(char*));            // array to hold the commands 
            char *tempcut = strtok(tmpIN, " ");                                     // cut the first command till the ' '

            while(tempcut != NULL){                                                 // keep cutting commands seperated by ' ' to the end of the string

                tempcut = strtok(NULL," ");                                         
                ctr++;                                                              // count the amount of commands
            }
                
            for(i=0; i<ctr; i++)

                seperated[i] = toExec[i];                                           // point to the strings
            

            file = toExec[i];                                                       // the last string is the name of the file
                
            if(drcount > 0){                                                        // in case the redirection is a > sign
                    
                pid_t son;

                son = fork();                                                       // create a son process

                if(son == 0){                                                       // in case this is the sone process

                    int fds = open(file, O_WRONLY | O_CREAT | O_TRUNC, S_IRWXU);    // change fd to the given file, with the right permissions
                        
                    if(dup2(fds, STDOUT_FILENO) == -1){                             // change output according to the fd

                        perror("couldn't change file descriptor");
                    }

                    else
                        execvp(seperated[0], seperated);                            // execute the command  
                        
                }

                else                                                                // in case this is the father process
                    wait(NULL);

            }

            if(odrcount > 0){                                                       // in case the redirection is a < sign
                    
                pid_t son;

                son = fork();                                                       // create a son process

                if(son == 0){                                                       // in case this is the sone process

                    int fds = open(file, O_RDONLY | O_CREAT, S_IRWXU);              // change fd to the given file, with the right permissions
                        
                    if(dup2(fds, STDIN_FILENO) == -1){                              // change input according to the fd  

                        perror("couldn't change file descriptor");
                    }

                    else
                        execvp(seperated[0], seperated);                            // execute the command
                        
                }

                else                                                                // in case this is the father process
                    wait(NULL);
            }

            if(ddrcount > 0){                                                       // in case the redirection is a >> sign

                pid_t son;

                son = fork();                                                       // create a son process

                if(son == 0){                                                       // in case this is the sone process

                    int fds = open(file, O_WRONLY | O_CREAT | O_APPEND, S_IRWXU);   // change fd to the given file, with the right permissions
                        
                    if(dup2(fds, STDOUT_FILENO) == -1){                             // change output according to the fd

                        perror("couldn't change file descriptor");
                    }

                    else
                        execvp(seperated[0], seperated);                            // execute the command
                        
                }

                else                                                                 // in case this is the father process
                    wait(NULL);
            }

            if(dr2count > 0){                                                       // in case the redirection is a 2> sign

                pid_t son;

                son = fork();                                                       // create a son process

                if(son == 0){                                                       // in case this is the sone process

                    int fds = open(file, O_WRONLY | O_CREAT | O_TRUNC, S_IRWXU);    // change fd to the given file, with the right permissions
                        
                    if(dup2(fds, STDERR_FILENO) == -1){                             // change error output according to the fd

                        perror("couldn't change file descriptor");
                    }

                    else
                        execvp(seperated[0], seperated);                            // execute the command
                        
                }

                else                                                                // in case this is the father process
                    wait(NULL);
            }

            commands++;
            drcommands++;
        }
    }
                                                        // after "done" has been entered
    free(input);                                        // free the input string

    cmdlen+=4;                                          // length of "done" command
    cmdavg = cmdlen / (commands);                       // calculate the average length of a command

    printf("Num of commands: %d\n", (int)(commands));   // print the reqired lines, casted on the relevant places
    printf("Total length of all commands: %d\n", (int)(cmdlen));
    printf("Average length of all commands: %f\n", cmdavg);
    printf("Number of command that include pipe: %d\n", (int)(pcommands));
    printf("Number of command that include redirection: %d\n", (int)(drcommands));
    printf("See you Next time !\n");

    return 0;
}

